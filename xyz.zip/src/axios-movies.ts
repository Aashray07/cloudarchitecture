
import axios from 'axios'
/** base url to make requests to the movie database */
console.log("hey")
console.log('API Key:', process.env.API_KEY);
const instance = axios.create({
  baseURL: 'https://api.themoviedb.org/3',
  params: {
    api_key: process.env.API_KEY,
  },
})

export default instance


